package com.vaadin.book.examples;

/** Example category. */
public class ExampleCtgr extends CaptionedExampleItem {
    private static final long serialVersionUID = 418811233718496311L;

    /** Create a new category. */
    public ExampleCtgr(String itemid, String shortName) {
        super(itemid, shortName);
    }
}